//
//  TableViewController.swift
//  Libros3
//
//  Created by Raul Guerra Hernandez on 1/4/17.
//  Copyright © 2017 Raul Guerra Hernandez. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController, ViewControllerBusquedaDelegate {
    
    
    var contexto : NSManagedObjectContext? = nil
    
    // Titulo, Autores, Portada
    private var libros : Array<LibroDM> = Array<LibroDM>()
    
    @IBOutlet weak var buttonNuevoLibro: UIBarButtonItem!
    @IBOutlet var tableLibros: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Libros buscados"
        
        self.contexto = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        leerTitulosLibrosCoreData()
    }
    
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.libros.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaReutilizable", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = self.libros[indexPath.row].nombre;
        
        return cell
    }
    


    
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if let barButton = sender as? UIBarButtonItem {
            if barButton == buttonNuevoLibro {
                //Do what you want
                let vistaBusqueda = segue.destination as! ViewControllerBusqueda
                vistaBusqueda.delegate = self
            }
        }else{        
            let vistaDetalle = segue.destination as! ViewControllerDetalle
            let ip = self.tableView.indexPathForSelectedRow
            vistaDetalle.libroDetalle = self.libros[ip!.row]
        }
    }
    
    
    
    
    
    func myVCDidFinish(controller:ViewControllerBusqueda, libroBuscado:LibroDM) {
        self.libros.append(libroBuscado)

        insertarLibroEnCoreData(libroBuscado: libroBuscado)
        self.tableLibros.reloadData()
    }
    
    
    
    
    
    // ----- Core Data -----
    
    // Insertar libro
    
    func insertarLibroEnCoreData(libroBuscado:LibroDM){
        
        let entity = NSEntityDescription.entity(forEntityName: "EntityLibro", in: contexto!)
        let transc = NSManagedObject(entity: entity!, insertInto: contexto!)
        
        //set the entity values
        transc.setValue(libroBuscado.nombre, forKey: "nombre")
        transc.setValue(libroBuscado.autores, forKey: "autores")
        transc.setValue(libroBuscado.imagen, forKey: "imagen")

        //save the object
        do {
            try contexto?.save()
            print("saved!")
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        } catch {
            print("error al guardar")
        }
        
        
    }
    
    
    func leerTitulosLibrosCoreData(){
        
        // Create Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "EntityLibro")
        
        // Add Sort Descriptor
        let sortDescriptor = NSSortDescriptor(key: "nombre", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let records = try contexto?.fetch(fetchRequest) as! [NSManagedObject]
            
            for record in records {
                var libroCD : LibroDM = LibroDM()
                libroCD.nombre  = record.value(forKey: "nombre") as! String
                libroCD.autores = record.value(forKey: "autores") as! String
                libroCD.imagen  = record.value(forKey: "imagen") as! Data
                self.libros.append(libroCD)
            }
            
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        
        
    }



    
    

}
