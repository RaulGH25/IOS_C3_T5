//
//  ViewControllerBusqueda.swift
//  Libros3
//
//  Created by Raul Guerra Hernandez on 1/5/17.
//  Copyright © 2017 Raul Guerra Hernandez. All rights reserved.
//

import UIKit
import SystemConfiguration


protocol ViewControllerBusquedaDelegate{
    func myVCDidFinish(controller:ViewControllerBusqueda, libroBuscado:LibroDM)
}


class ViewControllerBusqueda: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var textLeer: UITextField!
    @IBOutlet weak var textTitulo: UILabel!
    @IBOutlet weak var textAutores: UILabel!
    @IBOutlet weak var cuadroImagen: UIImageView!
    
    
    var delegate:ViewControllerBusquedaDelegate? = nil
    
    var libroBuscado : LibroDM = LibroDM()
    
    var guardado : Bool = false
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.textLeer.delegate = self
        self.textLeer.enablesReturnKeyAutomatically = true
        
        
        // guardado = true
    }

    
    

    override func willMove(toParentViewController parent: UIViewController?) {
        super.willMove(toParentViewController: parent)
        print("Great!")
        saveLibro(sender: self)
    }

    
    
    // func saveLibro(sender : UIBarButtonItem) {
    func saveLibro(sender : Any) {
        if guardado{
            print("la accion se ha hecho")
            if (delegate != nil) {
                delegate!.myVCDidFinish(controller: self, libroBuscado: self.libroBuscado)
            }
        }

    }
    
    
    
    
    
    
    
    
    // TextField
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        //  Check internet connection
        if isInternetAvailable() {
            
            // If the conection is ok, search the book information
            
            let texto   : String = textLeer.text!
            let urls    : String = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + texto
            let url = NSURL(string : urls)
            let datos : NSData? = NSData(contentsOf: url! as URL)
            
            do {
                let json = try JSONSerialization.jsonObject(with: datos! as Data, options: .mutableLeaves)
                let dic1 = json as! NSDictionary
                print("ok1")
                
                // Check if the ISBN exist
                
                if dic1["ISBN:" + texto] != nil {
                 
                    let dic2 = dic1["ISBN:" + texto] as! NSDictionary
                    print("ok2")
                    
                    // ----- Mostrar titulo -----
                    
                    let titulo = dic2["title"] as! NSString as String
                    
                    self.textTitulo.text = titulo
                    self.libroBuscado.nombre = titulo//self.libroBuscado.append(titulo) //self.libroBuscado[0] = titulo
                    
                    // ----- Mostrar autores -----
                    
                    let AutoresJS = dic2["publishers"] as! NSArray
                    
                    var textoAutores = ""
                    var nombreAutor = ""
                    if AutoresJS.count > 1 {
                        textoAutores = "Autores:"
                    }else{
                        textoAutores = "Autor:"
                    }
                    
                    var contador = 1
                    for autor in AutoresJS {
                        if contador < AutoresJS.count{
                            nombreAutor = (autor as! NSDictionary)["name"] as! String
                            textoAutores = textoAutores + " " + nombreAutor + ","
                        }else{
                            nombreAutor = (autor as! NSDictionary)["name"] as! String
                            textoAutores = textoAutores + " " + nombreAutor
                        }
                        contador = contador + 1
                    }
                    
                    self.textAutores.text = textoAutores
                    self.libroBuscado.autores = textoAutores
                    // ----- Mostrar portada -----
                    
                    let dicImagenes = dic2["cover"] as! NSDictionary
                    let img_urls = dicImagenes["medium"] as! String
                    let img_url = NSURL(string : img_urls)
                    let img_datos = NSData(contentsOf: img_url! as URL)
                    
                    if let imagen = UIImage(data: img_datos! as Data){
                        self.cuadroImagen.image = imagen
                        self.libroBuscado.imagen = img_datos! as Data
                    }
                    
                    
                    // ----- Libro guardado correctamente -----
                    
                    guardado = true
                    
                }else{ // If ISBN exist
                    self.textAutores.text = "Ningún libro encontrado"
                }
                
            } catch  {
            }
        } else {
            // Tell the user that there is no internet conection
            self.textTitulo.text = "No hay conexión a internet"
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
    
    
    // Internet
    func isInternetAvailable() -> Bool
    {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }

    
    
    
    
    
    
}
