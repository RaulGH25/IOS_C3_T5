//
//  DataModelLibro.swift
//  Libros3
//
//  Created by Raul Guerra Hernandez on 1/8/17.
//  Copyright © 2017 Raul Guerra Hernandez. All rights reserved.
//

import Foundation

class LibroDM {
    
    var nombre      : String?   = nil
    var autores     : String?   = nil
    var imagen      : Data?     = nil
}
