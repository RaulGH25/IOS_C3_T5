//
//  ViewControllerDetalle.swift
//  Libros3
//
//  Created by Raul Guerra Hernandez on 1/4/17.
//  Copyright © 2017 Raul Guerra Hernandez. All rights reserved.
//

import UIKit
import SystemConfiguration

class ViewControllerDetalle: UIViewController {
    
    
    @IBOutlet weak var textTitulo: UILabel!
    @IBOutlet weak var textAutores: UILabel!
    @IBOutlet weak var cuadroImagen: UIImageView!
    
    
    //var libroDetalle : Array<String> = Array<String>()
    var libroDetalle : LibroDM = LibroDM()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        textTitulo.text = libroDetalle.nombre
        textAutores.text = libroDetalle.autores
        
        if let imagen = UIImage(data: libroDetalle.imagen! as Data){
            self.cuadroImagen.image = imagen
                
        }
    }
    
}
